println "External Script called";
number1 = execution.getVariable("number1");
number2 = execution.getVariable("number2");

totalAmount = number1 + number2